/** \file modplay.h
 * \brief Stub to the Sinister Development replay routine.
 *
 * Please credit "(c) 1995 Sinister Developments" if you use this.
 */
#ifndef _MODPLAY_H
#define _MODPLAY_H

#include <stddef.h>

/** Initialise the replay routine. */
void snd_init();

/** Initialise the given soundtracker module. */
void snd_init_music(char *mod_addr);

/** VBL interrupt handler. */
void snd_vbl_handler();

/** Play a sample. */
int snd_play_sample(char *start_addr, size_t length, char *loop_addr, size_t loop_length, int priority, int volume, int frequency);

/** Modify the given channel parameters. */
void snd_modify_channel(int channel, int volume, int frequency);

/** Clear the channels. */
void snd_clear_channels(int channel, int nb);

/** Set the music volume (0 to 255). */
void snd_set_music_volume(int volume);

/** Set the special effects volume (0 to 255). */
void snd_set_efx_volume(int volume);

/** Enable the music. */
void snd_enable_music();

/** Disable the music. */
void snd_disable_music();

#endif
